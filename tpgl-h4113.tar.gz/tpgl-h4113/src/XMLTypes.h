#ifndef MORETYPES_H
#define MORETYPES_H

using namespace std;
#include <list>
#include <utility>
#include <string>

typedef pair<string,string> ElementName;
typedef list<string> DTDList;

#endif // MORETYPES_H
