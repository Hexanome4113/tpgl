var searchData=
[
  ['getattributes',['getAttributes',['../class_x_m_l_node.html#a80ae04b136774fa6cd9075fa92148965',1,'XMLNode']]],
  ['getchildren',['getChildren',['../class_d_t_d_definition.html#ab5d59213f00ed5b638609ff0ed05105d',1,'DTDDefinition::getChildren()'],['../class_x_m_l_node.html#a1f4ea630819d007ddc5df02f331a1dcb',1,'XMLNode::getChildren()']]],
  ['getcontentspec',['getContentSpec',['../class_d_t_d_element.html#a5e7ac76ee99272cdb284cfa66f483187',1,'DTDElement']]],
  ['getdefinition',['getDefinition',['../class_d_t_d_element.html#a7ad86d221816caf2a98db21e0764adf9',1,'DTDElement']]],
  ['getdocumentroot',['getDocumentRoot',['../class_x_m_l_node.html#aca5e607598ba590d941f5140dde1c089',1,'XMLNode']]],
  ['getfullname',['getFullName',['../class_x_m_l_node.html#ae19a3896b76d3c9f2df6038a7c64bf27',1,'XMLNode']]],
  ['getnamespace',['getNameSpace',['../class_x_m_l_node.html#af5d4018320b4fd202409546e3e2d3347',1,'XMLNode']]],
  ['getnodename',['getNodeName',['../class_x_m_l_node.html#ab83c7475e30e92fca4813592fe00e353',1,'XMLNode']]],
  ['getnom',['getNom',['../class_d_t_d_definition.html#ae841f380428801005b8bcfc11577a5eb',1,'DTDDefinition::getNom()'],['../class_d_t_d_element.html#a983f5561bdbf1b7b7127908bad9e8b15',1,'DTDElement::getNom()']]],
  ['getparent',['getParent',['../class_x_m_l_node.html#ab53132738607b90b12146a8f850fbc9c',1,'XMLNode']]],
  ['getquantifier',['getQuantifier',['../class_d_t_d_definition.html#a4dedfabb1677ae2d868cf442f9d71a3f',1,'DTDDefinition']]],
  ['gettextcontent',['getTextContent',['../class_x_m_l_node.html#a320fd7d6ef15b2274352abff2a592397',1,'XMLNode']]],
  ['gettype',['getType',['../class_d_t_d_definition.html#a9cde9c722b5b2a52a0e4c11aa69e499c',1,'DTDDefinition']]]
];
