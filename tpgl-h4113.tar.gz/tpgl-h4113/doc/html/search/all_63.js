var searchData=
[
  ['cspecandvsstr',['CspecAndVsstr',['../struct_cspec_and_vsstr.html',1,'']]]
];
