var searchData=
[
  ['vsandstr',['VsAndStr',['../struct_vs_and_str.html',1,'']]]
];
