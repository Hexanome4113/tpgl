var searchData=
[
  ['dtddefinition',['DTDDefinition',['../class_d_t_d_definition.html#ac8b5be3c096bbdd9aee6e1f53d7289c0',1,'DTDDefinition::DTDDefinition()'],['../class_d_t_d_definition.html#aa961e4ed01574c6de5e6e73ffb4c9592',1,'DTDDefinition::DTDDefinition(DTDDefinitionType type, std::vector&lt; DTDDefinition &gt; children, std::string nom=&quot;&quot;, std::string quantifier=&quot;&quot;)']]],
  ['dtdelement',['DTDElement',['../class_d_t_d_element.html#a87171dd4bc6dbcb8ab12a2b5b69f9abc',1,'DTDElement::DTDElement()'],['../class_d_t_d_element.html#aed99d625783d40a963b6575f5b1b3b40',1,'DTDElement::DTDElement(std::string nom, ContentSpec contentSpec, DTDDefinition definition)']]]
];
