var searchData=
[
  ['setcontentspec',['setContentSpec',['../class_d_t_d_element.html#aa89f50c53ccebe15e30fdc1849ff1fad',1,'DTDElement']]],
  ['setdefinition',['setDefinition',['../class_d_t_d_element.html#a71243ea1102ba0d9731cfbc94d1f0593',1,'DTDElement']]],
  ['setnom',['setNom',['../class_d_t_d_definition.html#adba8f775dbfe57dbd3518e4121b05747',1,'DTDDefinition::setNom()'],['../class_d_t_d_element.html#a24c5e3b8285d0fbfaff34ca809fd2580',1,'DTDElement::setNom()']]],
  ['setquantifier',['setQuantifier',['../class_d_t_d_definition.html#adcaf15a63f7aea5f830afdfc547d7f0f',1,'DTDDefinition']]],
  ['settype',['setType',['../class_d_t_d_definition.html#a82ecfbe7e6b041a7c60ea2a08afd502f',1,'DTDDefinition']]]
];
