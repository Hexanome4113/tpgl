var searchData=
[
  ['xmlnode',['XMLNode',['../class_x_m_l_node.html',1,'XMLNode'],['../class_x_m_l_node.html#a15451e72788af9e387b7c37e36ae5904',1,'XMLNode::XMLNode(string textContent)'],['../class_x_m_l_node.html#af149f2fbac6fc753db2b5bd19ab581b5',1,'XMLNode::XMLNode(string nodeNamespace, string nodeName, map&lt; string, string &gt; attributeList)'],['../class_x_m_l_node.html#a5c5b1ad7daca4f5944d5270e8db1618f',1,'XMLNode::XMLNode(string nodeNamespace, string nodeName, map&lt; string, string &gt; attributeList, vector&lt; XMLNode * &gt; childrenList)']]]
];
