var searchData=
[
  ['iselementnode',['isElementNode',['../class_x_m_l_node.html#a8b228feaecb6906791035f6a003167f7',1,'XMLNode']]],
  ['istextnode',['isTextNode',['../class_x_m_l_node.html#aca2a516ac15814517653cc161d57a300',1,'XMLNode']]]
];
